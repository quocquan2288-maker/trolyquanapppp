package vn.quan.trolyquan.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val QuanDarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = ObsidianBg,
    secondary = ElectricViolet,
    onSecondary = TextPrimary,
    tertiary = HotAmber,
    background = ObsidianBg,
    onBackground = TextPrimary,
    surface = DeepSpaceSurface,
    onSurface = TextPrimary,
    surfaceVariant = GlassCardBg,
    onSurfaceVariant = TextSecondary,
    error = CrimsonAlert,
    onError = TextPrimary
)

@Composable
fun TroLyQuanTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = QuanDarkColorScheme,
        content = content
    )
}
