package vn.quan.trolyquan.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import vn.quan.trolyquan.domain.model.AssistantState
import vn.quan.trolyquan.ui.theme.TextPrimary
import vn.quan.trolyquan.ui.theme.TextSecondary

/**
 * Vòng cầu năng lượng AI & sóng âm thanh đa tầng (60fps Canvas).
 * Thay đổi màu sắc, tần số dao động và biên độ theo trạng thái của Trợ Lý Quân
 * và cường độ âm thanh thực tế từ Micro / Giọng đọc TTS.
 */
@Composable
fun NeonOrbVisualizer(
    state: AssistantState,
    audioAmplitude: Float,
    orbSize: Dp = 180.dp,
    onOrbClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "quan_orb_transition")

    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )

    val breathingScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathing_scale"
    )

    val smoothAmplitude by animateFloatAsState(
        targetValue = audioAmplitude.coerceIn(0.08f, 1.0f),
        animationSpec = tween(durationMillis = 90),
        label = "smooth_audio_amp"
    )

    val primaryColor by animateColorAsState(
        targetValue = Color(state.primaryHex),
        animationSpec = tween(durationMillis = 450),
        label = "primary_orb_color"
    )

    val secondaryColor by animateColorAsState(
        targetValue = Color(state.secondaryHex),
        animationSpec = tween(durationMillis = 450),
        label = "secondary_orb_color"
    )

    val interactionSource = remember { MutableInteractionSource() }

    Box(
        modifier = Modifier
            .size(orbSize)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onOrbClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val maxRadius = size.minDimension / 2f
            val baseRadius = maxRadius * 0.44f * breathingScale
            val dynamicBoost = if (state == AssistantState.LISTENING || state == AssistantState.SPEAKING) {
                smoothAmplitude * maxRadius * 0.24f
            } else if (state == AssistantState.THINKING || state == AssistantState.EXECUTING) {
                maxRadius * 0.12f * kotlin.math.abs(sin(phase * 2f))
            } else {
                maxRadius * 0.04f
            }

            // 1. Quầng sáng nền ngoài cùng (Ambient Neon Halo)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryColor.copy(alpha = 0.36f),
                        secondaryColor.copy(alpha = 0.14f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = maxRadius * 0.98f
                ),
                radius = maxRadius * 0.98f,
                center = center
            )

            // 2. Vẽ 28 thanh phổ tần số tròn xung quanh cầu (Radial Equalizer Bars)
            val barCount = 28
            val innerBarRadius = baseRadius + maxRadius * 0.12f
            for (i in 0 until barCount) {
                val angle = (i.toFloat() / barCount) * (2f * PI.toFloat()) + phase * 0.4f
                val waveFactor = kotlin.math.abs(sin(angle * 3f + phase * 2f))
                val barLength = (maxRadius * 0.05f) + (dynamicBoost * waveFactor * 1.15f)

                val startOffset = Offset(
                    x = center.x + cos(angle) * innerBarRadius,
                    y = center.y + sin(angle) * innerBarRadius
                )
                val endOffset = Offset(
                    x = center.x + cos(angle) * (innerBarRadius + barLength),
                    y = center.y + sin(angle) * (innerBarRadius + barLength)
                )

                drawLine(
                    brush = Brush.linearGradient(
                        colors = listOf(primaryColor.copy(alpha = 0.85f), secondaryColor.copy(alpha = 0.35f)),
                        start = startOffset,
                        end = endOffset
                    ),
                    start = startOffset,
                    end = endOffset,
                    strokeWidth = 3.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            // 3. Ba vòng sóng âm hài hòa (3 Harmonic Sine Wave Rings)
            val harmonicConfigs = listOf(
                Triple(5, 1.0f, primaryColor.copy(alpha = 0.80f)),
                Triple(7, -1.4f, secondaryColor.copy(alpha = 0.65f)),
                Triple(9, 2.1f, primaryColor.copy(alpha = 0.40f))
            )

            for ((lobes, speedMultiplier, ringColor) in harmonicConfigs) {
                val path = Path()
                val steps = 120
                for (step in 0..steps) {
                    val theta = (step.toFloat() / steps) * (2f * PI.toFloat())
                    val harmonicWave = sin(theta * lobes + phase * speedMultiplier)
                    val r = baseRadius + (dynamicBoost * 0.65f * harmonicWave)
                    val px = center.x + cos(theta) * r
                    val py = center.y + sin(theta) * r
                    if (step == 0) {
                        path.moveTo(px, py)
                    } else {
                        path.lineTo(px, py)
                    }
                }
                path.close()
                drawPath(
                    path = path,
                    color = ringColor,
                    style = Stroke(width = 2.2.dp.toPx())
                )
            }

            // 4. Lõi cầu năng lượng Glassmorphic Core
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryColor.copy(alpha = 0.90f),
                        secondaryColor.copy(alpha = 0.70f),
                        Color(0xFF0A0F1D)
                    ),
                    center = Offset(center.x - baseRadius * 0.25f, center.y - baseRadius * 0.25f),
                    radius = baseRadius * 1.15f
                ),
                radius = baseRadius * 0.86f,
                center = center
            )

            // 5. Viền sáng kim loại quanh lõi
            drawCircle(
                color = Color.White.copy(alpha = 0.35f),
                radius = baseRadius * 0.86f,
                center = center,
                style = Stroke(width = 1.5.dp.toPx())
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "QUÂN AI",
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.6.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = when (state) {
                    AssistantState.IDLE -> "Chạm để nói"
                    AssistantState.LISTENING -> "Đang nghe..."
                    AssistantState.THINKING -> "Đang nghĩ..."
                    AssistantState.EXECUTING -> "Đang chạy lệnh"
                    AssistantState.SPEAKING -> "Chạm để ngắt"
                    AssistantState.ERROR -> "Thử lại"
                },
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
