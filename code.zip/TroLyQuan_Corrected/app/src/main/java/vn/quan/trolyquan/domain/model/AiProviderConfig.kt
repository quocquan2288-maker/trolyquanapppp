package vn.quan.trolyquan.domain.model

/**
 * Các nhà cung cấp mô hình ngôn ngữ lớn (LLM) chính thức được hỗ trợ.
 */
enum class AiProviderType(
    val displayName: String,
    val defaultBaseUrl: String,
    val defaultModel: String,
    val officialKeyUrl: String,
    val description: String
) {
    GEMINI(
        displayName = "Google Gemini API (Khuyên dùng - Miễn phí)",
        defaultBaseUrl = "https://generativelanguage.googleapis.com/v1beta",
        defaultModel = "gemini-2.5-flash",
        officialKeyUrl = "https://aistudio.google.com/app/apikey",
        description = "API chính thức từ Google AI Studio, tốc độ nhanh, hiểu tiếng Việt tự nhiên và có gói miễn phí."
    ),
    GROQ(
        displayName = "Groq Cloud API (Siêu tốc - Có gói miễn phí)",
        defaultBaseUrl = "https://api.groq.com/openai/v1",
        defaultModel = "llama-3.3-70b-versatile",
        officialKeyUrl = "https://console.groq.com/keys",
        description = "Chuẩn OpenAI-compatible chạy trên chip LPU siêu tốc, độ trễ cực thấp cho trợ lý giọng nói."
    ),
    OPENAI_COMPATIBLE(
        displayName = "OpenAI / OpenRouter / Tùy chỉnh",
        defaultBaseUrl = "https://api.openai.com/v1",
        defaultModel = "gpt-4o-mini",
        officialKeyUrl = "https://platform.openai.com/api-keys",
        description = "Tương thích mọi máy chủ chuẩn OpenAI (/chat/completions) như OpenAI, OpenRouter, DeepSeek hoặc Local LLM."
    )
}

object DefaultApiKeyConfig {
    const val PRECONFIGURED_GEMINI_KEY = "AQ.Ab8RN6Kxyj_d2OPS4PAHxwQI3LW04Xnb2fZdDg-DCw1g_K7gKg"
}

data class AiSettings(
    val provider: AiProviderType = AiProviderType.GEMINI,
    val apiKey: String = DefaultApiKeyConfig.PRECONFIGURED_GEMINI_KEY,
    val baseUrl: String = AiProviderType.GEMINI.defaultBaseUrl,
    val modelName: String = AiProviderType.GEMINI.defaultModel,
    val voiceAutoSpeak: Boolean = true,
    val voicePitch: Float = 0.90f,
    val voiceRate: Float = 1.05f,
    val preferredVoiceName: String = "",
    val continuousListenAfterSpeak: Boolean = false,
    val allowSlangAndRoast: Boolean = true
)
