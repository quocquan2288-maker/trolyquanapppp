package vn.quan.trolyquan

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import vn.quan.trolyquan.ui.MainAssistantScreen
import vn.quan.trolyquan.ui.QuanViewModel
import vn.quan.trolyquan.ui.theme.TroLyQuanTheme

/**
 * MainActivity của ứng dụng TRỢ LÝ QUÂN.
 * Quản lý việc xin quyền thời gian thực (RECORD_AUDIO, CAMERA, CALL_PHONE)
 * và khởi chạy giao diện Jetpack Compose.
 */
class MainActivity : ComponentActivity() {

    private val viewModel: QuanViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            TroLyQuanTheme {
                val uiState by viewModel.uiState.collectAsState()

                var hasAudioPermission by remember {
                    mutableStateOf(checkPermissionGranted(Manifest.permission.RECORD_AUDIO))
                }
                var hasCameraPermission by remember {
                    mutableStateOf(checkPermissionGranted(Manifest.permission.CAMERA))
                }
                var hasCallPermission by remember {
                    mutableStateOf(checkPermissionGranted(Manifest.permission.CALL_PHONE))
                }

                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestMultiplePermissions()
                ) { permissionsMap ->
                    hasAudioPermission = permissionsMap[Manifest.permission.RECORD_AUDIO]
                        ?: checkPermissionGranted(Manifest.permission.RECORD_AUDIO)
                    hasCameraPermission = permissionsMap[Manifest.permission.CAMERA]
                        ?: checkPermissionGranted(Manifest.permission.CAMERA)
                    hasCallPermission = permissionsMap[Manifest.permission.CALL_PHONE]
                        ?: checkPermissionGranted(Manifest.permission.CALL_PHONE)
                }

                val requestEssentialPermissions = {
                    permissionLauncher.launch(
                        arrayOf(
                            Manifest.permission.RECORD_AUDIO,
                            Manifest.permission.CAMERA,
                            Manifest.permission.CALL_PHONE
                        )
                    )
                }

                MainAssistantScreen(
                    uiState = uiState,
                    hasAudioPermission = hasAudioPermission,
                    hasCameraPermission = hasCameraPermission,
                    hasCallPermission = hasCallPermission,
                    onRequestPermissions = requestEssentialPermissions,
                    onMicOrOrbClick = {
                        viewModel.onMicOrOrbClicked(
                            hasAudioPermission = hasAudioPermission,
                            onRequestAudioPermission = {
                                permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                            }
                        )
                    },
                    onStopSpeaking = { viewModel.stopQuanSpeaking() },
                    onSendMessage = { text -> viewModel.submitUserMessage(text, triggeredByVoice = false) },
                    onSpeakMessage = { text -> viewModel.speakMessage(text) },
                    onToggleTorch = { viewModel.toggleTorchDirect() },
                    onToggleVoiceAutoSpeak = { viewModel.toggleVoiceAutoSpeak() },
                    onClearHistory = { viewModel.clearHistory() },
                    onRefreshApps = { viewModel.refreshInstalledApps() },
                    onLaunchApp = { app -> viewModel.launchInstalledAppDirect(app) },
                    onExecuteDirectCommand = { cmd -> viewModel.executeDirectCommand(cmd) },
                    onSaveSettings = { newSettings -> viewModel.updateSettings(newSettings) },
                    onConfirmSensitiveAction = { viewModel.confirmPendingSensitiveAction() },
                    onCancelSensitiveAction = { viewModel.cancelPendingSensitiveAction() },
                    onDismissBanner = { viewModel.dismissDiagnosticBanner() }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshInstalledApps()
    }

    private fun checkPermissionGranted(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }
}
