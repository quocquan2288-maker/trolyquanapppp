package vn.quan.trolyquan.data.ai

import java.text.Normalizer
import java.util.Locale
import java.util.regex.Pattern
import vn.quan.trolyquan.domain.model.CommandType
import vn.quan.trolyquan.domain.model.SystemCommand

/**
 * Bộ phân tích lệnh tiếng Việt nội bộ (On-Device NLU Fallback & Fast-Path).
 * Đảm bảo các lệnh điều khiển điện thoại ('Mở TikTok', 'Mở YouTube', 'Mở Chrome',
 * 'Mở cài đặt', 'Bật đèn pin', 'Tăng âm lượng'...) LUÔN hoạt động tức thì 100%
 * kể cả khi điện thoại mất mạng hoặc người dùng chưa nhập API Key.
 */
object LocalCommandFallbackParser {

    data class ParsedDecision(
        val replyText: String,
        val moodTag: String,
        val command: SystemCommand,
        val isConfidentSystemCommand: Boolean
    )

    fun normalizeVietnamese(input: String): String {
        val temp = Normalizer.normalize(input.trim(), Normalizer.Form.NFD)
        val pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+")
        return pattern.matcher(temp)
            .replaceAll("")
            .replace('đ', 'd')
            .replace('Đ', 'D')
            .lowercase(Locale.ROOT)
            .replace(Regex("\\s+"), " ")
    }

    fun parseUserText(rawInput: String): ParsedDecision {
        val clean = rawInput.trim()
        val norm = normalizeVietnamese(clean)

        // 1. BẬT / TẮT ĐÈN PIN (FLASH / TORCH)
        if (norm.contains("den pin") || norm.contains("den flash") || norm.contains("flash")) {
            val turnOff = norm.contains("tat") || norm.contains("ngat") || norm.contains("dong")
            return if (turnOff) {
                ParsedDecision(
                    replyText = "Đã tắt đèn pin rồi nhé ông tướng! Đỡ tốn pin máy.",
                    moodTag = "THANG_THAN",
                    command = SystemCommand(
                        type = CommandType.TORCH_CONTROL,
                        booleanValue = false
                    ),
                    isConfidentSystemCommand = true
                )
            } else {
                ParsedDecision(
                    replyText = "Ok đại ca, bật đèn pin sáng trưng luôn đây!",
                    moodTag = "NHIET_TINH",
                    command = SystemCommand(
                        type = CommandType.TORCH_CONTROL,
                        booleanValue = true
                    ),
                    isConfidentSystemCommand = true
                )
            }
        }

        // 2. ĐIỀU CHỈNH ÂM LƯỢNG (VOLUME)
        if (norm.contains("am luong") || norm.contains("tieng") || norm.contains("volume")) {
            val percentMatch = Regex("(\\d{1,3})\\s*%").find(norm)
            if (percentMatch != null) {
                val level = percentMatch.groupValues[1].toIntOrNull()?.coerceIn(0, 100) ?: 50
                return ParsedDecision(
                    replyText = "Đã chỉnh âm lượng máy về mức $level% chuẩn đét rồi nhé!",
                    moodTag = "THANG_THAN",
                    command = SystemCommand(
                        type = CommandType.VOLUME_CONTROL,
                        target = "SET",
                        intValue = level
                    ),
                    isConfidentSystemCommand = true
                )
            }
            if (norm.contains("het co") || norm.contains("toi da") || norm.contains("max")) {
                return ParsedDecision(
                    replyText = "Máu thế nhờ! Đã vặn âm lượng lên mức tối đa luôn rồi nhé, coi chừng điếc tai đấy!",
                    moodTag = "CA_KHIA",
                    command = SystemCommand(
                        type = CommandType.VOLUME_CONTROL,
                        target = "MAX",
                        intValue = 100
                    ),
                    isConfidentSystemCommand = true
                )
            }
            if (norm.contains("tat tieng") || norm.contains("im lang") || norm.contains("mute") || norm.contains("ve 0")) {
                return ParsedDecision(
                    replyText = "Ok, đã đưa âm lượng media về 0% im phăng phắc rồi nhé.",
                    moodTag = "NGHIEM_TUC",
                    command = SystemCommand(
                        type = CommandType.VOLUME_CONTROL,
                        target = "MUTE",
                        intValue = 0
                    ),
                    isConfidentSystemCommand = true
                )
            }
            if (norm.contains("tang") || norm.contains("to len") || norm.contains("lon len") || norm.contains("bat to")) {
                return ParsedDecision(
                    replyText = "Đã tăng âm lượng lên cho ông rồi đấy, nghe rõ chưa?",
                    moodTag = "THANG_THAN",
                    command = SystemCommand(
                        type = CommandType.VOLUME_CONTROL,
                        target = "UP"
                    ),
                    isConfidentSystemCommand = true
                )
            }
            if (norm.contains("giam") || norm.contains("nho xuong") || norm.contains("be xuong") || norm.contains("ha am")) {
                return ParsedDecision(
                    replyText = "Đã giảm bớt âm lượng xuống rồi nhé!",
                    moodTag = "THANG_THAN",
                    command = SystemCommand(
                        type = CommandType.VOLUME_CONTROL,
                        target = "DOWN"
                    ),
                    isConfidentSystemCommand = true
                )
            }
        }

        // 3. ĐẶT BÁO THỨC (SET ALARM)
        if (norm.contains("bao thuc") || norm.contains("danh thuc")) {
            val timeRegex = Regex("(\\d{1,2})\\s*(?:gio|h|:)\\s*(\\d{1,2})?")
            val match = timeRegex.find(norm)
            if (match != null) {
                val hour = match.groupValues[1].toIntOrNull()?.coerceIn(0, 23) ?: 7
                val minute = match.groupValues[2].toIntOrNull()?.coerceIn(0, 59) ?: 0
                val formattedTime = String.format(Locale.US, "%02d:%02d", hour, minute)
                return ParsedDecision(
                    replyText = "Xong! Đặt báo thức lúc $formattedTime cho ông rồi đấy. Nhớ dậy đúng giờ, đừng có nướng khét lẹt nhé!",
                    moodTag = "CA_KHIA",
                    command = SystemCommand(
                        type = CommandType.SET_ALARM,
                        hour = hour,
                        minute = minute,
                        stringValue = "Trợ Lý Quân gọi dậy"
                    ),
                    isConfidentSystemCommand = true
                )
            }
        }

        // 4. HẸN GIỜ (SET TIMER)
        if (norm.contains("hen gio") || norm.contains("dem nguoc")) {
            val minMatch = Regex("(\\d+)\\s*phut").find(norm)
            val secMatch = Regex("(\\d+)\\s*giay").find(norm)
            val minutes = minMatch?.groupValues?.get(1)?.toIntOrNull() ?: 0
            val seconds = secMatch?.groupValues?.get(1)?.toIntOrNull() ?: 0
            val totalSeconds = (minutes * 60) + seconds
            if (totalSeconds > 0) {
                return ParsedDecision(
                    replyText = "Đã lên lịch hẹn giờ đếm ngược cho đại ca rồi nhé!",
                    moodTag = "NHIET_TINH",
                    command = SystemCommand(
                        type = CommandType.SET_TIMER,
                        intValue = totalSeconds,
                        stringValue = "Hẹn giờ Trợ Lý Quân"
                    ),
                    isConfidentSystemCommand = true
                )
            }
        }

        // 5. GỌI ĐIỆN / QUAY SỐ (SENSITIVE ACTION -> YÊU CẦU XÁC NHẬN)
        if (norm.startsWith("goi ") || norm.startsWith("goi dien ") || norm.startsWith("quay so ")) {
            val digits = Regex("(\\+?\\d[\\d\\s.-]{6,14}\\d)").find(clean)?.groupValues?.get(1)
                ?.replace(Regex("[^\\d+]"), "")
            if (!digits.isNullOrBlank()) {
                return ParsedDecision(
                    replyText = "Ông muốn gọi tới số $digits thật đúng không? Chuyện tiền nong cước phí nhạy cảm, bấm nút Xác nhận trên màn hình giúp tôi cái!",
                    moodTag = "NGHIEM_TUC",
                    command = SystemCommand(
                        type = CommandType.CALL_NUMBER,
                        stringValue = digits,
                        requiresConfirmation = true
                    ),
                    isConfidentSystemCommand = true
                )
            }
        }

        // 6. MỞ CÀI ĐẶT HỆ THỐNG & WI-FI / BLUETOOTH
        if (norm.contains("cai dat") || norm.contains("setting") || norm.contains("wifi") || norm.contains("wi-fi") || norm.contains("bluetooth")) {
            when {
                norm.contains("wifi") || norm.contains("wi-fi") || norm.contains("mang khong day") -> {
                    return ParsedDecision(
                        replyText = "Từ Android 10 trở lên Google cấm app tự gạt Wi-Fi ngầm rồi ông ơi. Tôi bật sẵn bảng điều khiển Wi-Fi lên đây, ông chạm tay gạt cái là xong!",
                        moodTag = "THANG_THAN",
                        command = SystemCommand(
                            type = CommandType.WIFI_PANEL,
                            target = "WIFI"
                        ),
                        isConfidentSystemCommand = true
                    )
                }
                norm.contains("bluetooth") -> {
                    return ParsedDecision(
                        replyText = "Mở ngay màn hình cài đặt Bluetooth cho đại ca đây!",
                        moodTag = "NHIET_TINH",
                        command = SystemCommand(
                            type = CommandType.OPEN_SETTINGS,
                            target = "BLUETOOTH"
                        ),
                        isConfidentSystemCommand = true
                    )
                }
                norm.contains("am thanh") || norm.contains("chuong") -> {
                    return ParsedDecision(
                        replyText = "Đã mở cài đặt Âm thanh & Rung của máy!",
                        moodTag = "THANG_THAN",
                        command = SystemCommand(
                            type = CommandType.OPEN_SETTINGS,
                            target = "SOUND"
                        ),
                        isConfidentSystemCommand = true
                    )
                }
                norm.contains("man hinh") || norm.contains("do sang") -> {
                    return ParsedDecision(
                        replyText = "Đã mở cài đặt Màn hình & Độ sáng!",
                        moodTag = "THANG_THAN",
                        command = SystemCommand(
                            type = CommandType.OPEN_SETTINGS,
                            target = "DISPLAY"
                        ),
                        isConfidentSystemCommand = true
                    )
                }
                norm.contains("pin") -> {
                    return ParsedDecision(
                        replyText = "Mở thông tin Pin của máy cho ông kiểm tra đây!",
                        moodTag = "THANG_THAN",
                        command = SystemCommand(
                            type = CommandType.OPEN_SETTINGS,
                            target = "BATTERY"
                        ),
                        isConfidentSystemCommand = true
                    )
                }
                norm.contains("vi tri") || norm.contains("gps") -> {
                    return ParsedDecision(
                        replyText = "Mở cài đặt Vị trí (GPS) cho ông đây!",
                        moodTag = "THANG_THAN",
                        command = SystemCommand(
                            type = CommandType.OPEN_SETTINGS,
                            target = "LOCATION"
                        ),
                        isConfidentSystemCommand = true
                    )
                }
                norm.contains("mo cai dat") || norm == "cai dat" || norm.contains("vao cai dat") || norm.contains("settings") -> {
                    return ParsedDecision(
                        replyText = "Mở Cài đặt hệ thống lên ngay cho nóng!",
                        moodTag = "NHIET_TINH",
                        command = SystemCommand(
                            type = CommandType.OPEN_SETTINGS,
                            target = "MAIN"
                        ),
                        isConfidentSystemCommand = true
                    )
                }
            }
        }

        // 7. TÌM KIẾM YOUTUBE HOẶC GOOGLE
        if ((norm.contains("youtube") && (norm.contains("tim ") || norm.contains("mo nhac") || norm.contains("phat "))) ||
            norm.startsWith("tim tren youtube ")
        ) {
            val query = clean
                .replace(Regex("(?i)(mở|bật|tìm|trên|youtube|video|bài hát|nhạc)"), "")
                .trim()
                .ifBlank { clean }
            return ParsedDecision(
                replyText = "Để Quân mở YouTube tìm '$query' cho ông giải trí nhé!",
                moodTag = "NHIET_TINH",
                command = SystemCommand(
                    type = CommandType.YOUTUBE_SEARCH,
                    stringValue = query
                ),
                isConfidentSystemCommand = true
            )
        }

        if (norm.startsWith("tim google ") || norm.startsWith("tim kiem ") || norm.startsWith("tra cuu ")) {
            val query = clean.replace(Regex("(?i)^(tìm google|tìm kiếm|tra cứu)\\s*"), "").trim()
            if (query.isNotBlank()) {
                return ParsedDecision(
                    replyText = "Đợi tí, mở trình duyệt tìm '$query' trên Google cho ông xem ngay đây!",
                    moodTag = "NHIET_TINH",
                    command = SystemCommand(
                        type = CommandType.WEB_SEARCH,
                        stringValue = query
                    ),
                    isConfidentSystemCommand = true
                )
            }
        }

        // 8. MỞ ỨNG DỤNG BẤT KỲ ('Mở TikTok', 'Mở YouTube', 'Mở Chrome', 'Bật Zalo'...)
        val openAppPrefixes = listOf(
            "mo ung dung ", "bat ung dung ", "chay ung dung ",
            "mo app ", "bat app ", "vao app ",
            "mo ", "bat ", "vao "
        )
        for (prefix in openAppPrefixes) {
            if (norm.startsWith(prefix)) {
                val appTarget = norm.removePrefix(prefix)
                    .replace(Regex("\\b(len|cho toi|giup toi|dum toi|cai|nhe|di)\\b"), "")
                    .trim()
                if (appTarget.isNotBlank() && appTarget.length <= 40) {
                    val wittyReply = when {
                        appTarget.contains("tiktok") || appTarget.contains("tik tok") ->
                            "Lại lướt TikTok đấy à ông tướng? Mở cho thì mở, nhớ đừng thức khuya quá nhé!"
                        appTarget.contains("youtube") ->
                            "Ok đại ca, bật YouTube lên ngay đây!"
                        appTarget.contains("chrome") || appTarget.contains("trinh duyet") ->
                            "Mở trình duyệt Chrome cho ông lướt web ngay đây!"
                        appTarget.contains("zalo") ->
                            "Mở Zalo lên kiểm tra tin nhắn ngay nhé!"
                        appTarget.contains("facebook") || appTarget == "fb" ->
                            "Bật Facebook lên cho ông hóng biến ngay đây!"
                        else ->
                            "Rõ rồi ông bạn! Để Quân mở $appTarget lên cho."
                    }
                    return ParsedDecision(
                        replyText = wittyReply,
                        moodTag = if (appTarget.contains("tiktok")) "CA_KHIA" else "NHIET_TINH",
                        command = SystemCommand(
                            type = CommandType.OPEN_APP,
                            target = appTarget
                        ),
                        isConfidentSystemCommand = true
                    )
                }
            }
        }

        // 9. TRẢ LỜI OFFLINE KHI CHƯA CÓ API KEY HOẶC MẤT MẠNG
        val fallbackReply = when {
            norm.contains("ten gi") || norm.contains("la ai") ->
                "Tôi là Quân — trợ lý AI kiêm chiến hữu trên con máy Android này của ông! Cần mở app, bật đèn pin, chỉnh âm lượng hay chém gió gì cứ phất lệnh!"
            norm.contains("chao") || norm == "alo" || norm == "hi" || norm == "hello" ->
                "Chào đại ca! Gọi Quân có việc gì sai bảo đấy? Mở TikTok, bật đèn pin hay tâm sự mỏng?"
            norm.contains("lam duoc gi") || norm.contains("chuc nang") ->
                "Tôi mở được mọi app đã cài trên máy ông (TikTok, YouTube, Chrome, Zalo...), bật/tắt đèn pin thật, tăng giảm âm lượng, mở cài đặt hệ thống, đặt báo thức và chém gió hai chiều bằng giọng nói tiếng Việt!"
            else ->
                "Nghe rõ câu '$clean' của ông rồi! Hiện tại mạng đang chập chờn hoặc khóa API chưa phản hồi nên Quân đang trực chiến bằng bộ xử lý nội bộ. Mấy lệnh như 'Mở TikTok', 'Mở YouTube', 'Bật đèn pin', 'Tăng âm lượng' thì tôi vẫn chạy vèo vèo không cần mạng luôn nhé!"
        }

        return ParsedDecision(
            replyText = fallbackReply,
            moodTag = "CA_KHIA",
            command = SystemCommand(type = CommandType.NONE),
            isConfidentSystemCommand = false
        )
    }
}
